# -*- coding: iso8859-1 -*-
#
# Copyright (C) 2005 Matthew Good <trac@matt-good.net>
#
# "THE BEER-WARE LICENSE" (Revision 42):
# <trac@matt-good.net> wrote this file.  As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a beer in return.   Matthew Good
#
# Author: Matthew Good <trac@matt-good.net>
# Hacked for the Mythtv Project by Stuart Morgan <stuart@tase.co.uk>

import md5
import time

from trac.core import *

from trac.db import *
from trac.db.sqlite_backend import SQLiteConnection

from emailops import AccountEmail

class AccountManager(Component):

    def __init__(self):
        self.projectname = self.env.config.get('project', 'name')

    def get_db(self):
        """Return a database connection"""
        path = self.env.config.get('acmhack', 'database')
        return SQLiteConnection(path)

    def has_user(self, user):
        db = self.get_db()
        cursor = db.cursor()
        sql = """SELECT username
                FROM trac_users
                WHERE username= %s AND projectname=%s"""
        cursor.execute(sql, (user, self.projectname))
        row = cursor.fetchone()
        if not row:
            ret = False
        else:
            ret = True
        db.close()
        return ret

    def has_code(self, code):
        db = self.get_db()
        cursor = db.cursor()
        sql = """SELECT email
                FROM trac_users
                WHERE code= %s AND projectname=%s"""
        cursor.execute(sql, (code, self.projectname))
        row = cursor.fetchone()
        if not row:
            ret = False
        else:
            ret = True
        db.close()
        return ret

    def get_users(self):
        db = self.get_db()
        cursor = db.cursor()
        sql = """SELECT username
                FROM trac_users WHERE projectname=%s"""
        cursor.execute(sql, (self.projectname))

        for username in cursor:
            users.append(username[0])

        db.close()
        return users

    def get_email(self, user):
        db = self.get_db()
        cursor = db.cursor()
        sql = """SELECT email FROM trac_users
                WHERE username=%s AND projectname=%s"""
        cursor.execute(sql, (user, self.projectname))
        email = cursor.fetchone()
        db.close()
        return email[0]

    def create_user(self, user, password, email):
        db = self.get_db()
        cursor = db.cursor()
        hashpass = md5.new();
        hashpass.update(password);
        code = md5.new(str(time.time()))
        sql = """INSERT INTO trac_users VALUES
                (%s, %s, %s, %s, 'False', %s, %s)"""
        cursor.execute(sql, (self.projectname,
                user, hashpass.hexdigest(), email, code.hexdigest(), int(time.time())))
        db.commit()
        if cursor.rowcount > 0:
            db.close()
            AccountEmail(self.env).sendVerificationEmail(email, code.hexdigest())
            return True;
        else:
            db.close()
            return False;

    def reverify_user(self, user, email):
        db = self.get_db()
        cursor = db.cursor()
        code = md5.new(str(time.time()))
        sql = """UPDATE trac_users SET
                verified=%s, code=%s WHERE username=%s AND projectname=%s"""
        cursor.execute(sql, ('False', code.hexdigest(), user, self.projectname))
        db.commit()
        if cursor.rowcount > 0:
            db.close()
            AccountEmail(self.env).sendVerificationEmail(email, code.hexdigest())
            return True;
        else:
            db.close()
            return False;

    def verify_user(self, code):
        db = self.get_db()
        cursor = db.cursor()
        sql = """UPDATE trac_users SET
                verified=%s WHERE code=%s AND projectname=%s"""
        cursor.execute(sql, ('True', code, self.projectname))
        db.commit()
        if cursor.rowcount > 0:
            db.close()
            return True;
        else:
            db.close()
            return False;

    def is_verified(self, user):
        db = self.get_db()
        cursor = db.cursor()
        sql = """SELECT * FROM trac_users WHERE username=%s AND verified=%s AND projectname=%s"""
        cursor.execute(sql, (user, 'True', self.projectname))
        row = cursor.fetchone()
        if not row:
            ret = False
        else:
            ret = True
        db.close()
        return ret

    def is_banned(self, user):
        db = self.get_db()
        cursor = db.cursor()
        sql = """SELECT * FROM trac_users WHERE username=%s AND verified=%s AND projectname=%s"""
        cursor.execute(sql, (user, 'Ban', self.projectname))
        row = cursor.fetchone()
        if not row:
            ret = False
        else:
            ret = True
        db.close()
        return ret

    def set_password(self, user, password):
        db = self.get_db()
        cursor = db.cursor()
        hashpass = md5.new();
        hashpass.update(password);
        sql = """UPDATE trac_users SET
                password=%s WHERE username=%s AND projectname=%s"""
        cursor.execute(sql, (hashpass.hexdigest(), user, self.projectname))
        db.commit()
        if cursor.rowcount > 0:
            db.close()
            return True;
        else:
            db.close()
            return False;

    def set_email(self, user, email):
        db = self.get_db()
        cursor = db.cursor()
        sql = """UPDATE trac_users SET
                email=%s WHERE username=%s AND projectname=%s"""
        cursor.execute(sql, (email, user, self.projectname))
        db.commit()
        if cursor.rowcount > 0:
            db.close()
            return True;
        else:
            db.close()
            return False;

    def ban_user(self, user):
        db = self.get_db()
        cursor = db.cursor()
        sql = """UPDATE trac_users SET verified=%s WHERE username=%s AND projectname=%s"""
        cursor.execute(sql, ('Ban', user, self.projectname))
        db.commit()
        if cursor.rowcount > 0:
            db.close()
            return True;
        else:
            db.close()
            return False;

    def unban_user(self, user):
        db = self.get_db()
        cursor = db.cursor()
        sql = """UPDATE trac_users SET verified=%s WHERE username=%s AND projectname=%s"""
        cursor.execute(sql, ('True', user, self.projectname))
        db.commit()
        if cursor.rowcount > 0:
            db.close()
            return True;
        else:
            db.close()
            return False;

    def delete_user(self, user):
        db = self.get_db()
        cursor = db.cursor()
        sql = """DELETE FROM trac_users WHERE username=%s AND projectname=%s"""
        cursor.execute(sql, (user, self.projectname))
        db.commit()
        if cursor.rowcount > 0:
            db.close()
            return True;
        else:
            db.close()
            return False;

