# -*- coding: iso8859-1 -*-
#
#   Derived from the Notify.py module of Trac
#
# Written for the Mythtv Project by Stuart Morgan <stuart@tase.co.uk>

import time
import smtplib

from trac.core import *

class AccountEmail(Component):

    def __init__(self):
        self.projectname = self.env.config.get('project', 'name')
        self.webaddress = self.env.config.get('acmhack', 'trac_url')

    def sendVerificationEmail(self, email, code):
        self.config = self.env.config

        self.subject = self.projectname + " Trac Email Confirmation"

        if not self.config.getbool('notification', 'smtp_enabled'):
            return
        self.smtp_server = self.config.get('notification', 'smtp_server')
        self.smtp_port = int(self.config.get('notification', 'smtp_port'))
        self.from_email = self.config.get('notification', 'smtp_from')
        self.replyto_email = self.config.get('notification', 'smtp_replyto')
        self.from_email = self.from_email or self.replyto_email
        if not self.from_email and not self.replyto_email:
            raise TracError('Unable to send email due to identity crisis. <br />'
                            'Both <b>notification.from</b> and'
                            ' <b>notification.reply_to</b> are unspecified'
                            ' in configuration.',
                            'SMTP Notification Error')

        # Authentication info (optional)
        self.user_name = self.config.get('notification', 'smtp_user')
        self.password = self.config.get('notification', 'smtp_password')


        self.server = smtplib.SMTP(self.smtp_server, self.smtp_port)
        if self.user_name:
            self.server.login(self.user_name, self.password)

        from email.Utils import formatdate

        msg = "From: " + self.from_email + "\r\nTo: " + email + "\r\n";
        msg += "Date: " + formatdate() + "\r\n";
        msg += "Subject: " + self.subject + "\r\n\r\n";
        msg += "To activate your " + self.projectname + " Trac account, open this link in your browser:\r\n\r\n";
        msg += self.webaddress + "/verifyemail?code=" + code;


        self.env.log.debug("Sending SMTP email verification to %s on port %d"
                        % (self.smtp_server, self.smtp_port))
        self.server.sendmail(self.from_email, email, msg)

        self.server.quit()
