# -*- coding: iso8859-1 -*-
#
# Copyright (C) 2005 Matthew Good <trac@matt-good.net>
#
# "THE BEER-WARE LICENSE" (Revision 42):
# <trac@matt-good.net> wrote this file.  As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a beer in return.   Matthew Good
#
# Author: Matthew Good <trac@matt-good.net>
# Hacked for the Mythtv Project by Stuart Morgan <stuart@tase.co.uk>

from __future__ import generators

import re
import time
import md5

from trac.core import *
from trac.web import auth
from trac.web.api import IAuthenticator, IRequestHandler
from trac.web.chrome import INavigationContributor, ITemplateProvider
from trac.util import escape, hex_entropy, TracError, Markup

from acmhack.dbops import AccountManager
from acmhack.emailops import *

class AccountModule(Component):
    """Allows users to change their password or delete their account.
    The settings for the AccountManager module must be set in trac.ini
    in order to use this.
    """

    implements(INavigationContributor, IRequestHandler, ITemplateProvider)

    #INavigationContributor methods
    def get_active_navigation_item(self, req):
        return 'account'

    def get_navigation_items(self, req):
        if req.authname != 'anonymous':
            yield 'metanav', 'account', Markup('<a href="%s">My Account</a>',
                                               (self.env.href.account()))

    # IRequestHandler methods
    def match_request(self, req):
        return req.path_info == '/account'

    def process_request(self, req):
        if req.authname == 'anonymous':
            req.redirect(self.env.href.wiki())
        action = req.args.get('action')
        if req.method == 'POST':
            if action == 'change_password':
                self._do_change_password(req)
            elif action == 'change_email':
                self._do_change_email(req)
            elif action == 'delete':
                self._do_delete(req)
        req.hdf['account.email'] = AccountManager(self.env).get_email(req.authname)
        req.hdf['account.name'] = req.authname
        return 'account.cs', None

    def _do_change_password(self, req):
        user = req.authname
        password = req.args.get('password')
        if not password:
            req.hdf['account.error'] = 'Password cannot be empty.'
            return

        if password != req.args.get('password_confirm'):
            req.hdf['account.error'] = 'The passwords must match.'
            return

        if AccountManager(self.env).set_password(user, password):
            req.hdf['account.message'] = 'Password successfully updated.'
        else:
            req.hdf['account.message'] = 'Password NOT updated due to DB error.'

    def _do_change_email(self, req):
        user = req.authname
        email = req.args.get('email_address')
        if not email:
            req.hdf['account.error'] = 'Email cannot be empty.'
            return

        if re.match("^.+\\@(\\[?)[a-zA-Z0-9\\-\\.]+\\.([a-zA-Z]{2,3}|[0-9]{1,4})(\\]?)$", email) == None:
            req.hdf['registration.error'] = 'The Email address does not seem valid.'
            return

        if AccountManager(self.env).set_email(user, email):
            req.hdf['account.message'] = 'Email successfully updated. You must now verify your new email'
            AccountManager(self.env).reverify_user(user, email)
            DbAuthLoginModule(self.env)._do_logout(req)
        else:
            req.hdf['account.message'] = 'Email NOT updated due to DB error.'

    def _do_delete(self, req):
        user = req.authname
        AccountManager(self.env).delete_user(user)
        req.redirect(self.env.href.logout())

    # ITemplateProvider

    def get_htdocs_dirs(self):
        """Return the absolute path of a directory containing additional
        static resources (such as images, style sheets, etc).
        """
        return []

    def get_templates_dirs(self):
        """Return the absolute path of the directory containing the provided
        ClearSilver templates.
        """
        from pkg_resources import resource_filename
        return [resource_filename(__name__, 'templates')]

class RegistrationModule(Component):
    """Provides users the ability to register a new account.
    Requires configuration of the AccountManager module in trac.ini.
    """

    implements(INavigationContributor, IRequestHandler, ITemplateProvider)

    #INavigationContributor methods

    def get_active_navigation_item(self, req):
        return 'register'

    def get_navigation_items(self, req):
        if req.authname == 'anonymous':
            yield 'metanav', 'register', Markup('<a href="%s">Register</a>',
                                                (self.env.href.register()))

    # IRequestHandler methods

    def match_request(self, req):
        return req.path_info == '/register'

    def process_request(self, req):
        if req.authname != 'anonymous':
            req.redirect(self.env.href.account())
        action = req.args.get('action')
        if req.method == 'POST' and action == 'create':
            self._do_create(req)
        return 'register.cs', None

    def _do_create(self, req):
        mgr = AccountManager(self.env)

        user = req.args.get('user')
        if mgr.has_user(user):
            req.hdf['registration.error'] = \
                'Another account with that name already exists.'
            return

        password = req.args.get('password')
        if not password:
            req.hdf['registration.error'] = 'Password cannot be empty.'
            return

        email = req.args.get('email_address')
        if not email:
            req.hdf['registration.error'] = 'Email cannot be empty.'
            return

        if re.match("^.+\\@(\\[?)[a-zA-Z0-9\\-\\.]+\\.([a-zA-Z]{2,3}|[0-9]{1,4})(\\]?)$", email) == None:
            req.hdf['registration.error'] = 'The Email address does not seem valid.'
            return

        if password != req.args.get('password_confirm'):
            req.hdf['registration.error'] = 'The passwords must match.'
            return

        mgr.create_user(user, password, email)
        req.redirect(self.env.href.login())

    # ITemplateProvider

    def get_htdocs_dirs(self):
        """Return the absolute path of a directory containing additional
        static resources (such as images, style sheets, etc).
        """
        return []

    def get_templates_dirs(self):
        """Return the absolute path of the directory containing the provided
        ClearSilver templates.
        """
        from pkg_resources import resource_filename
        return [resource_filename(__name__, 'templates')]

class EmailVerificationModule(Component):
    """ Veries the registration email of the user.
    """

    implements(IRequestHandler, ITemplateProvider)

    # IRequestHandler methods

    def match_request(self, req):
        return req.path_info == '/verifyemail'

    def process_request(self, req):
        if req.authname != 'anonymous':
            req.redirect(self.env.href.account())
        action = req.args.get('action')
        if req.method == 'GET':
            self._do_verify(req)
        return 'verification.cs', None

    def _do_verify(self, req):
        mgr = AccountManager(self.env)

        code = req.args.get('code')
        if not code:
            req.hdf['verification.error'] = \
                'No verification code provided'
            return

        if not mgr.has_code(code):
            req.hdf['verification.error'] = \
                'Sorry but the verification code provided was not valid.'
            return

        req.hdf['verification.message'] = \
            'Your email address has been verfied, you may now login'
        mgr.verify_user(code)

    # ITemplateProvider

    def get_htdocs_dirs(self):
        """Return the absolute path of a directory containing additional
        static resources (such as images, style sheets, etc).
        """
        return []

    def get_templates_dirs(self):
        """Return the absolute path of the directory containing the provided
        ClearSilver templates.
        """
        from pkg_resources import resource_filename
        return [resource_filename(__name__, 'templates')]

class DbAuthLoginModule(Component):
    """Implements user authentication based on database tables and an HTML form,
    combined with cookies for communicating the login information across the whole site.
    """

    implements(IAuthenticator, INavigationContributor, ITemplateProvider, IRequestHandler)

    def __init__(self):
        self.projectname = self.env.config.get('project', 'name')

    # IAuthenticator methods

    def authenticate(self, req):
        authname = None
        if req.remote_user:
            authname = req.remote_user
        elif req.incookie.has_key('trac_db_auth'):
            authname = self._get_name_for_cookie(req, req.incookie['trac_db_auth'])

        if not authname:
            return None

        if self.config.getbool('trac', 'ignore_auth_case'):
            authname = authname.lower()

        return authname

    # INavigationContributor methods

    def get_active_navigation_item(self, req):
        return 'login'

    def get_navigation_items(self, req):
        if req.authname and req.authname != 'anonymous':
            yield 'metanav', 'login', 'logged in as %s' % req.authname
            yield 'metanav', 'logout', Markup( '<a href="%s">Logout</a>' \
                  % escape(self.env.href.logout()) )
        else:
            yield 'metanav', 'login', Markup( '<a href="%s">Login</a>' \
                  % escape(self.env.href.login()) )

    # IRequestHandler methods

    def match_request(self, req):
        return re.match('/(login|logout)/?', req.path_info)

    def process_request(self, req):
        if req.method == 'POST':
            if req.args.get('login'):
                user, password = req.args.get('user'), req.args.get('password')

                if self._check_login(user, password) and not AccountManager(self.env).is_verified(user):
                    req.hdf["auth.message"] = "Sorry your email address not been confirmed"
                elif AccountManager(self.env).is_banned(user):
                    req.hdf["auth.message"] = "Sorry this username has been banned"
                elif self._check_login(user, password):
                    self._do_login(req)
                    req.redirect(self.env.href.wiki())
                else:
                    req.hdf["auth.message"] = "Login Incorrect"


        if req.path_info.startswith('/login'):
            # self._do_login(req)
            template = "login.cs"
        elif req.path_info.startswith('/logout'):
            self._do_logout(req)
            req.redirect(self.env.href.login())
        return template, None

    # ITemplateProvider methods

    def get_htdocs_dirs(self):
        """Return the absolute path of a directory containing additional
        static resources (such as images, style sheets, etc).
        """
        from pkg_resources import resource_filename
        return [('acmhack', resource_filename(__name__, 'htdocs'))]

    def get_templates_dirs(self):
        """Return the absolute path of the directory containing the provided
        ClearSilver templates.
        """
        from pkg_resources import resource_filename
        return [resource_filename(__name__, 'templates')]

    # Internal methods

    def _check_login(self, user, password):
        mgr = AccountManager(self.env)
        db = mgr.get_db()
        cursor = db.cursor()
        hashpass = md5.new();
        hashpass.update(password);
        sql = """SELECT username
                 FROM trac_users
                 WHERE username= %s and password = %s
                   AND projectname = %s AND verified=%s"""
        cursor.execute(sql, (user, hashpass.hexdigest(), self.projectname, 'True'))
        row = cursor.fetchone()
        if not row:
            ret = False
        else:
            ret = True

        return ret

    def _do_login(self, req):
        """Log the remote user in."""

        remote_user, password = req.args.get('user'), req.args.get('password')
        remote_user = remote_user.lower()

        cookie = hex_entropy()
        mgr = AccountManager(self.env)
        db = mgr.get_db()
        cursor = db.cursor()
        cursor.execute("INSERT INTO trac_cookies "
                       "(projectname, cookie, username, ipnr, unixtime) "
                       "VALUES (%s, %s, %s, %s, %s)", (self.projectname, cookie, remote_user,
                       req.remote_addr, int(time.time())))
        db.commit()

        req.authname = remote_user
        req.outcookie['trac_db_auth'] = cookie
        req.outcookie['trac_db_auth']['expires'] = 100000000
        req.outcookie['trac_db_auth']['path'] = self.env.href()

    def _do_logout(self, req):
        """Log the user out.

        Simply deletes the corresponding record from the auth_cookie table.
        """
        if req.authname == 'anonymous':
            # Not logged in
            return

        mgr = AccountManager(self.env)
        db = mgr.get_db()
        cursor = db.cursor()
        cursor.execute("DELETE FROM trac_cookies "
                       "WHERE username=%s "
                       "  AND projectname=%s",
                       (req.authname, self.projectname))
        db.commit()
        self._expire_cookie(req)

    def _expire_cookie(self, req):
        """Instruct the user agent to drop the auth cookie by setting the
        "expires" property to a date in the past.
        """
        req.outcookie['trac_db_auth'] = ''
        req.outcookie['trac_db_auth']['path'] = self.env.href()
        req.outcookie['trac_db_auth']['expires'] = -10000

    def _get_name_for_cookie(self, req, cookie):
        mgr = AccountManager(self.env)
        db = mgr.get_db()
        cursor = db.cursor()
        cursor.execute("SELECT username FROM trac_cookies "
                       "WHERE cookie=%s AND projectname=%s",
                           (cookie.value,self.projectname))
        row = cursor.fetchone()
        if not row:
            # The cookie is invalid (or has been purged from the database), so
            # tell the user agent to drop it as it is invalid
            self._expire_cookie(req)
            return None

        return row[0]

    def _redirect_back(self, req):
        """Redirect the user back to the URL she came from."""
        referer = req.get_header('Referer')
        if referer and not referer.startswith(req.base_url):
            # only redirect to referer if the latter is from the same
            # instance
            referer = None
        req.redirect(referer or self.env.abs_href())

class AdministrationModule(Component):
    """Provides users the ability to register a new account.
    Requires configuration of the AccountManager module in trac.ini.
    """

    implements(INavigationContributor, IRequestHandler, ITemplateProvider)

    #INavigationContributor methods

    def get_active_navigation_item(self, req):
        return 'useradmin'

    def get_navigation_items(self, req):
        if req.perm.has_permission('TRAC_ADMIN'):
            yield 'metanav', 'useradmin', Markup('<a href="%s">User Admin</a>',
                                                (self.env.href.useradmin()))

    # IRequestHandler methods

    def match_request(self, req):
        return req.path_info == '/useradmin'

    def process_request(self, req):
        req.perm.assert_permission('TRAC_ADMIN')

        action = req.args.get('action')
        if req.method == 'POST' and action == 'lookup_username':
            self._do_search(req)
        elif req.method == 'POST' and action == 'delete':
            self._do_delete(req)
        elif req.method == 'POST' and action == 'ban':
            self._do_ban(req)
        elif req.method == 'POST' and action == 'unban':
            self._do_unban(req)
        return 'useradmin.cs', None

    def _do_search(self, req):
        mgr = AccountManager(self.env)

        user = req.args.get('username')
        if not mgr.has_user(user):
            req.hdf['manage.error'] = \
                'Sorry no account exists with that username'
            return
        else:
            if mgr.is_banned(user):
                req.hdf['manage.user_is_banned'] = True
            req.hdf['manage.user_email'] = mgr.get_email(user)
            req.hdf['manage.username'] = user
            req.hdf['manage.have_user'] = True

    def _do_ban(self, req):
        mgr = AccountManager(self.env)

        user = req.args.get('username')
        if not mgr.has_user(user):
            req.hdf['manage.error'] = \
                'Sorry no account exists with that username'
            return
        else:
            mgr.ban_user(user)
            req.hdf['manage.message'] = 'User ' + user + ' banned.'

    def _do_unban(self, req):
        mgr = AccountManager(self.env)

        user = req.args.get('username')
        if not mgr.has_user(user):
            req.hdf['manage.error'] = \
                'Sorry no account exists with that username'
            return
        else:
            mgr.unban_user(user)
            req.hdf['manage.message'] = 'User ' + user + ' unbanned.'

    def _do_delete(self, req):
        mgr = AccountManager(self.env)

        user = req.args.get('username')
        if not mgr.has_user(user):
            req.hdf['manage.error'] = \
                'Sorry no account exists with that username'
            return
        else:
            mgr.delete_user(user)
            req.hdf['manage.message'] = 'User account ' + user + ' deleted.'

    # ITemplateProvider

    def get_htdocs_dirs(self):
        """Return the absolute path of a directory containing additional
        static resources (such as images, style sheets, etc).
        """
        return []

    def get_templates_dirs(self):
        """Return the absolute path of the directory containing the provided
        ClearSilver templates.
        """
        from pkg_resources import resource_filename
        return [resource_filename(__name__, 'templates')]