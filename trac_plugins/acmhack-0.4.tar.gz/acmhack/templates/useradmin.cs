<?cs include "header.cs"?>
<?cs include "macros.cs"?>

<div id="ctxtnav" class="nav"></div>

<div id="content" class="register">

 <h1>User Admin</h1>

 <p>
 Enter a username to administer.<br />
 </p>

 <form method="post" action="">
  <div>
   <input type="hidden" name="action" value="lookup_username" />
   <label for="username">Username:</label>
   <input type="username" id="username" name="username" class="textwidget"
          size="20" />
  </div>
  <input type="submit" value="Lookup Username" />
 </form>

 <?cs if manage.error ?>
 <hr />
 <div class="system-message">
  <h2>Error</h2>
  <p><?cs var:manage.error ?></p>
 </div>
 <?cs /if ?>

 <?cs if manage.message ?>
 <hr />
 <p><?cs var:manage.message ?></p>
 <?cs /if ?>

 <?cs if manage.have_user ?>

 <hr />

 <p>
 <h2>User: <?cs var:manage.username ?><br />
 Email address: <?cs var:manage.user_email ?><br /><br />
 Please choose what you would like to do:<br />
 </p>

 <?cs if manage.user_is_banned ?>

 <form method="post" action="">
  <input type="hidden" name="action" value="unban" />
  <input type="hidden" name="username" value="<?cs var:manage.username ?>" />
  <input type="submit" value="Remove user ban" />
 </form>

 <?cs else ?>

 <form method="post" action=""
       onsubmit="return confirm('Are you sure you want to ban <?cs var:manage.username ?>?');">
  <input type="hidden" name="action" value="ban" />
  <input type="hidden" name="username" value="<?cs var:manage.username ?>" />
  <input type="submit" value="Ban user" />
 </form>

 <?cs /if ?>

 <form method="post" action=""
       onsubmit="return confirm('Are you sure you want to delete the account of <?cs var:manage.username ?>?');">
  <input type="hidden" name="action" value="delete" />
  <input type="hidden" name="username" value="<?cs var:manage.username ?>" />
  <input type="submit" value="Delete account" />
 </form>

 <?cs /if ?>

</div>

<?cs include:"footer.cs"?>
