<?cs include "header.cs"?>
<?cs include "macros.cs"?>
<h2>Email Verification</h2>
<style type="text/css">
p.error {color: red; font-weight: bold;}
</style>
<p class="error"><?cs var:verification.error ?></p>
<p><?cs var:verification.message ?></p>
<br />
<?cs include:"footer.cs"?>
