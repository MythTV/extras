#!/usr/bin/env python
# -*- coding: utf-8 -*-
#

from setuptools import setup, find_packages

PACKAGE = 'TracAccountManHack'
VERSION = '0.4'

setup(
    name=PACKAGE, version=VERSION,
    description='Trac plugin for auth via database, email verification etc',
    author="Stuart Morgan", author_email="stuart@tase.co.uk",
    license='BSD', url='http://www.actiongames.co.uk/acm/',
    packages=find_packages(exclude=['ez_setup', '*.tests*']),
    package_data={'acmhack': ['templates/*.cs']},
    entry_points = {
        'trac.plugins': [
            'acmhack.manage = acmhack.manage'
        ]
    }

)
