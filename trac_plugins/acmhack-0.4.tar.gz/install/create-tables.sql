--DROP TABLE trac_users;

CREATE TABLE trac_users (
	projectname text NOT NULL , 
	username text NOT NULL ,
	password text NOT NULL ,
	email text ,
	verified text NOT NULL ,
	code text NOT NULL ,
	reg_time int NOT NULL ,
	UNIQUE (projectname, username)
);

--DROP TABLE trac_cookies;

CREATE TABLE trac_cookies (
	projectname text NOT NULL ,
	cookie text NOT NULL ,
	username text NOT NULL ,
	ipnr text NOT NULL ,
	unixtime int NOT NULL 
);

